% (c) Copyright 2014, 2023 Advanced Micro Devices, Inc. All rights reserved.
%
% This file contains confidential and proprietary information
% of AMD and is protected under U.S. and international copyright
% and other intellectual property laws.
%
% DISCLAIMER
% This disclaimer is not a license and does not grant any
% rights to the materials distributed herewith. Except as
% otherwise provided in a valid license issued to you by
% AMD, and to the maximum extent permitted by applicable
% law: (1) THESE MATERIALS ARE MADE AVAILABLE "AS IS" AND
% WITH ALL FAULTS, AND AMD HEREBY DISCLAIMS ALL WARRANTIES
% AND CONDITIONS, EXPRESS, IMPLIED, OR STATUTORY, INCLUDING
% BUT NOT LIMITED TO WARRANTIES OF MERCHANTABILITY, NON-
% INFRINGEMENT, OR FITNESS FOR ANY PARTICULAR PURPOSE; and
% (2) AMD shall not be liable (whether in contract or tort,
% including negligence, or under any other theory of
% liability) for any loss or damage of any kind or nature
% related to, arising under or in connection with these
% materials, including for any direct, or any indirect,
% special, incidental, or consequential loss or damage
% (including loss of data, profits, goodwill, or any type of
% loss or damage suffered as a result of any action brought
% by a third party) even if such damage or loss was
% reasonably foreseeable or AMD had been advised of the
% possibility of the same.
%
% CRITICAL APPLICATIONS
% AMD products are not designed or intended to be fail-
% safe, or for use in any application requiring fail-safe
% performance, such as life-support or safety devices or
% systems, Class III medical devices, nuclear facilities,
% applications related to the deployment of airbags, or any
% other applications that could lead to death, personal
% injury, or severe property or environmental damage
% (individually and collectively, "Critical
% Applications"). Customer assumes the sole risk and
% liability of any use of AMD products in Critical
% Applications, subject only to applicable laws and
% regulations governing limitations on product liability.
%
% THIS COPYRIGHT NOTICE AND DISCLAIMER MUST BE RETAINED AS
% PART OF THIS FILE AT ALL TIMES.
%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%
%Call divide
%  [quotient]                     =divide(model,dividend,divisor)
% Fractional Remainder (included in quotient):
%  [quotient,div_by_zeo]          =divide(model,dividend,divisor)
% Integer Remainder:
%  [quotient,remainder]           =divide(model,dividend,divisor)
%  [quotient,remainder,div_by_zeo]=divide(model,dividend,divisor)
%
%In
%  model           Model object
%  dividend        Dividend data
%  divisor         Divisor data
%
%Out
%  quotient        Quotient
%  remainder       Integer remainder
%  div_by_zeo      Divide by Zero indicator
%
function varargout=divide(model,dividend,divisor)
  % How many outputs?
  nOutputs = nargout;
  if nOutputs == 0
    nOutputs = 1;
  end
  varargout = cell(1,nOutputs);
  
  % Ensure dividend & divisor are the correct shape
  % o C Model requires a 1D array
  dividend_1d = reshape(dividend,prod(size(dividend)),1);
  divisor_1d  = reshape(divisor,prod(size(divisor)),1);
  
  [quotient,remainder,div_by_zeo] = div_gen_v5_1_bitacc_mex(4,model.shandle,dividend_1d,divisor_1d);
  
  % Reshape to match input shape
  quotient   = reshape(quotient,size(dividend));
  remainder  = reshape(remainder,size(dividend));
  div_by_zeo = reshape(div_by_zeo,size(dividend));
  
  varargout{1} = quotient;
  
  if model.config.remainder_type == 1
    % Fractional remainder type, combined in quotient.
    if nOutputs > 1
      varargout{2} = div_by_zeo;
    end
  else
    if nOutputs > 1
      varargout{2} = remainder;
    end
    if nOutputs > 2
      varargout{3} = div_by_zeo;
    end
  end

end

